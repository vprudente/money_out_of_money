fp = fopen('EURUSD_2015.txt')
C = textscan (fp,['%s %d %d', repmat('%f',[1,6])],'Delimiter',',','headerlines',1);
fclose(fp)
data = cell2mat(C(:,4:9));
t=data(:,1);
p=length(data);
new_data=zeros(p-1,6);
for i=1:p-1
    new_data(i,:)=data(i,:)-data(i+1,:);
end
N = 12688;  
tau=1;
m=2688;
N2=N-tau*(m-1);
S = zeros(N2,N2);
for i=1:N2
    y=new_data(i:tau:i+tau*(m-1),5);
    k=1;
    while k<=N2
        x=new_data(k:tau:k+tau*(m-1),5);
        S(i,k)=norm(y-x);
        k=k+1;
    end
end
D=reshape(S,N2*N2,1);
C=sort(D,'descend');
c=(length(C)*0.5);
c1=cast(c,'int64');
imagesc(t, t, S<C(c1)) %bianco e nero
axis square
colormap([1 1 1;0 0 0])
xlabel('Time'), ylabel('Time')


