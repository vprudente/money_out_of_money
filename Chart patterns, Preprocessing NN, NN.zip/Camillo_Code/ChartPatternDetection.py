import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import datetime


import seaborn as sns
sns.set()

from sklearn.metrics import r2_score, median_absolute_error, mean_absolute_error
from sklearn.metrics import median_absolute_error, mean_squared_error, mean_squared_log_error

from scipy.optimize import minimize
import statsmodels.tsa.api as smt
import statsmodels.api as sm

from tqdm import tqdm_notebook

from itertools import product


forex = pd.read_csv('https://docs.google.com/spreadsheets/d/e/2PACX-1vTGK41prmzXAybarmL369fq8V80BDDzjifcXRdV6GjzNt_Afe_bdMiXJJklnFXJGucMbkW9aDJFqMfa/pub?gid=1172511973&single=true&output=csv', header=0, infer_datetime_format=True, parse_dates=['DATE'], index_col=['DATE'])


"""##Smoothing"""
def mean_absolute_percentage_error(y_true, y_pred):
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

import warnings
warnings.filterwarnings('ignore')

# %matplotlib inline

def plot_moving_average(series, window, plot_intervals=False, scale=1.96):

    rolling_mean = series.rolling(window=window).mean()

    plt.figure(figsize=(17,8))
    plt.title('Moving average\n window size = {}'.format(window))
    plt.plot(rolling_mean, 'g', label='Rolling mean trend')

    
    #Plot confidence intervals for smoothed values
    if plot_intervals:
        mae = mean_absolute_error(series[window:], rolling_mean[window:])
        deviation = np.std(series[window:] - rolling_mean[window:])
        lower_bound = rolling_mean - (mae + scale * deviation)
        upper_bound = rolling_mean + (mae + scale * deviation)
        plt.plot(upper_bound, 'r--', label='Upper bound / Lower bound')
        plt.plot(lower_bound, 'r--')
            
    plt.plot(series[window:], label='Actual values')
    plt.xlabel("Time")
    plt.ylabel('Daily closing price')
    plt.title('Currency pair USD/EUR 2015-2019')
    plt.legend(loc='best')
    plt.grid(True)

plot_moving_average(forex['CLOSE'], 480, plot_intervals=True)

def tsplot(y, lags=None, figsize=(12, 7), syle='bmh'):
    
    if not isinstance(y, pd.Series):
        y = pd.Series(y)
        
    with plt.style.context(style='bmh'):
        fig = plt.figure(figsize=figsize)
        layout = (2,2)
        ts_ax = plt.subplot2grid(layout, (0,0), colspan=2)
        acf_ax = plt.subplot2grid(layout, (1,0))
        pacf_ax = plt.subplot2grid(layout, (1,1))
        
        y.plot(ax=ts_ax)
        p_value = sm.tsa.stattools.adfuller(y)[1]
        ts_ax.set_title('Time Series Analysis Plots\n Dickey-Fuller: p={0:.5f}'.format(p_value))
        smt.graphics.plot_acf(y, lags=lags, ax=acf_ax)
        smt.graphics.plot_pacf(y, lags=lags, ax=pacf_ax)
        plt.tight_layout()
        
tsplot(forex['CLOSE'], lags=480)

data_diff = forex['CLOSE'] - forex['CLOSE'].shift(96)
# day
tsplot(data_diff[1:], lags=96)

"""#Head and Shoulders Pattern
return the integer index values with price, for each min/max point
"""

from __future__ import division
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
import pandas as pd
import numpy as np
from statsmodels.nonparametric.kernel_regression import KernelReg
from numpy import linspace
import seaborn as sns

"""Smoothing the data using the kernel regression allows us to skip over minima and maxima that are too local."""

forex.reset_index()

prices_ = forex['CLOSE'][:10000].copy()
prices_.index = linspace(1., 10000, 10000)

# I've chosen bandwith parameters manually. This is something that could be improved.
kr = KernelReg([prices_.values], [prices_.index.values], var_type='c')
f = kr.fit([prices_.index.values])
smooth_prices = pd.Series(data=f[0], index=prices_.index)

smooth_prices

prices_.plot()
smooth_prices.plot()
plt.legend(['actual prices', 'smoothed prices'])

"""use the minima and maxima from the smoothed timeseries to identify true local minima and maxima in the original timeseres by taking the maximum/minimum price within a t-1, t+1 window around the smooth timeseries maxima/minima (purple points in the plots below)."""

from scipy.signal import argrelextrema

local_max = argrelextrema(smooth_prices.values, np.greater)[0]
local_min = argrelextrema(smooth_prices.values, np.less)[0]

local_max_dt = smooth_prices.iloc[local_max].index.values
local_min_dt = smooth_prices.iloc[local_min].index.values

price_local_max_dt = []
for i in local_max:
    if (i>5) and (i<len(prices_)-5):
        price_local_max_dt.append(prices_.iloc[i-1:i+1].idxmax())

price_local_min_dt = []
for i in local_min:
    if (i>5) and (i<len(prices_)-5):
        price_local_min_dt.append(prices_.iloc[i-1:i+1].idxmin())

prices_

def plot_window(prices, smooth_prices, smooth_maxima_dt, smooth_minima_dt,
                price_maxima_dt, price_minima_dt, ax=None):
    if ax is None:
        fig = plt.figure(figsize=(18,10))
        ax = fig.add_subplot(111)

    prices_ = prices
    prices_.plot(ax=ax)
    smooth_prices_ = smooth_prices
    smooth_prices_.plot(ax=ax, color='blue')
    
    smooth_max = smooth_prices_.loc[smooth_maxima_dt]
    smooth_min = smooth_prices_.loc[smooth_minima_dt]
    price_max = prices_.loc[price_maxima_dt]
    price_min = prices_.loc[price_minima_dt]


    
    ax.scatter(price_max.index.values, price_max.values, s=20, color='green')
    ax.scatter(price_min.index.values, price_min.values, s=20, color='red')

    
plot_window(prices_, 
            smooth_prices, 
            local_max_dt, 
            local_min_dt, 
            price_local_max_dt, 
            price_local_min_dt)

"""Green: Maxima

Red: Minima
"""

def find_max_min(prices):
    prices_ = prices.copy()
    prices_.index = linspace(1., len(prices_), len(prices_))
    kr = KernelReg([prices_.values], [prices_.index.values], var_type='c')
    f = kr.fit([prices_.index.values])
    smooth_prices = pd.Series(data=f[0], index=prices.index)
    
    local_max = argrelextrema(smooth_prices.values, np.greater)[0]
    local_min = argrelextrema(smooth_prices.values, np.less)[0]
    
    price_local_max_dt = []
    for i in local_max:
        if (i>1) and (i<len(prices)-1):
            price_local_max_dt.append(prices.iloc[i-2:i+2].idxmax())

    price_local_min_dt = []
    for i in local_min:
        if (i>1) and (i<len(prices)-1):
            price_local_min_dt.append(prices.iloc[i-2:i+2].idxmin())
        
    prices.name = 'price'
    maxima = pd.DataFrame(prices.loc[price_local_max_dt])
    minima = pd.DataFrame(prices.loc[price_local_min_dt])
    max_min = pd.concat([maxima, minima]).sort_index()
    max_min.index.name = 'date'
    max_min = max_min.reset_index()
    max_min = max_min[~max_min.date.duplicated()]
    p = prices.reset_index()
    max_min['day_num'] = p[p['index'].isin(max_min.date)].index.values
    max_min = max_min.set_index('day_num').price
    
    return max_min

max_min = find_max_min(prices_)

"""####Pattern detection
Use the maxima and minima to detect the head and shoulders patterns (normal & inverse) and the triangles (top & bottom)
"""

from collections import defaultdict

def find_patterns(max_min):
    patterns = defaultdict(list)

    for i in range(5, len(max_min)):
        window = max_min.iloc[i-5:i]

        # pattern must play out in less than 36 days
        if window.index[-1] - window.index[0] > 40:
            continue

        # Using the notation from the paper to avoid mistakes
        e1 = window.iloc[0]
        e2 = window.iloc[1]
        e3 = window.iloc[2]
        e4 = window.iloc[3]
        e5 = window.iloc[4]

        rtop_g1 = np.mean([e1,e3,e5])
        rtop_g2 = np.mean([e2,e4])
        # Head and Shoulders
        if (e1 > e2) and (e3 > e1) and (e3 > e5) and \
            (abs(e1 - e5) <= 0.03*np.mean([e1,e5])) and \
            (abs(e2 - e4) <= 0.03*np.mean([e1,e5])):
                patterns['HS'].append((window.index[0], window.index[-1]))

        # Inverse Head and Shoulders
        elif (e1 < e2) and (e3 < e1) and (e3 < e5) and \
            (abs(e1 - e5) <= 0.03*np.mean([e1,e5])) and \
            (abs(e2 - e4) <= 0.03*np.mean([e1,e5])):
                patterns['IHS'].append((window.index[0], window.index[-1]))

        # Triangle Top
        elif (e1 > e2) and (e1 > e3) and (e3 > e5) and (e2 < e4):
            patterns['TTOP'].append((window.index[0], window.index[-1]))

        # Triangle Bottom
        elif (e1 < e2) and (e1 < e3) and (e3 < e5) and (e2 > e4):
            patterns['TBOT'].append((window.index[0], window.index[-1]))

            
    return patterns

patterns = find_patterns(max_min)
patterns