"""##Tensorflow Time Series"""

forex = pd.read_csv('https://docs.google.com/spreadsheets/d/e/2PACX-1vTGK41prmzXAybarmL369fq8V80BDDzjifcXRdV6GjzNt_Afe_bdMiXJJklnFXJGucMbkW9aDJFqMfa/pub?gid=1172511973&single=true&output=csv')

forex

forex_test = pd.read_csv('https://docs.google.com/spreadsheets/d/e/2PACX-1vTyJ6_6qFYYQ1N8DdvVS3j4pYRraQxGZlEQ9ONqC4Ab57LjGr8zYKf3cznHRhtT3vvIwa7ye7iecEV2/pub?gid=1503978141&single=true&output=csv')

forex_test

forex = forex.append(forex_test, ignore_index=True)

forex

# Commented out IPython magic to ensure Python compatibility.
from __future__ import absolute_import, division, print_function, unicode_literals
try:
  # %tensorflow_version only exists in Colab.
#   %tensorflow_version 2.x
except Exception:
  pass
import tensorflow as tf

import matplotlib as mpl
import matplotlib.pyplot as plt
import os

mpl.rcParams['figure.figsize'] = (8, 6)
mpl.rcParams['axes.grid'] = False

tf.random.set_seed(13)

def create_time_steps(length):
  return list(range(-length, 0))

def show_plot(plot_data, delta, title):
  labels = ['History', 'True Future', 'Model Prediction']
  marker = ['.-', 'rx', 'go']
  time_steps = create_time_steps(plot_data[0].shape[0])
  if delta:
    future = delta
  else:
    future = 0

  plt.title(title)
  for i, x in enumerate(plot_data):
    if i:
      plt.plot(future, plot_data[i], marker[i], markersize=10,
               label=labels[i])
    else:
      plt.plot(time_steps, plot_data[i].flatten(), marker[i], label=labels[i])
  plt.legend()
  plt.xlim([time_steps[0], (future+5)*2])
  plt.xlabel('Time-Step')
  return plt

"""##Forecast a multivariate time series"""

#features_considered = ['Vol', 'dailyClose', 'dailyLow',	'dailyHigh']
#target on position 1
features_considered = ['VOL', 'CLOSE', 'trend_macd',	'momentum_rsi', 'trend_ichimoku_a', 'trend_ichimoku_b'] # 15 min

features = forex[features_considered] # 15 min data
features.index = forex['DATE']

#features = daily_Dataframe[features_considered] # daily data
#features.index = daily_Dataframe['Date']

#features2 = forex_test[features_considered]
#features2.index = forex_test['DATE']

features.plot(subplots=True)

#TRAIN_SPLIT = 1200
TRAIN_SPLIT = 114851 # For 15 min data (127613*90%)

dataset = features.values
#data_mean = dataset[:TRAIN_SPLIT].mean(axis=0)
#data_std = dataset[:TRAIN_SPLIT].std(axis=0)
#dataset = (dataset-data_mean)/data_std

def multivariate_data(dataset, target, start_index, end_index, history_size,
                      target_size, step, single_step=False):
  data = []
  labels = []

  start_index = start_index + history_size
  if end_index is None:
    end_index = len(dataset) - target_size

  for i in range(start_index, end_index):
    indices = range(i-history_size, i, step)
    data.append(dataset[indices])

    if single_step:
      labels.append(target[i+target_size])
    else:
      labels.append(target[i:i+target_size])

  return np.array(data), np.array(labels)

"""### Multi-Step model
Learn to predict a range of future values / predict a sequence of the future (next 6 days)

The dataset needs to be prepared accordingly / a different target window
"""

# every 15 min: 4 x 24 hours = 96, 96 * 5 days = 480 timesteps
past_history = 480
future_target = 96
STEP = 1

x_train_multi, y_train_multi = multivariate_data(dataset, dataset[:, 1], 0,
                                                 TRAIN_SPLIT, past_history,
                                                 future_target, STEP)
x_val_multi, y_val_multi = multivariate_data(dataset, dataset[:, 1],
                                             TRAIN_SPLIT, None, past_history,
                                             future_target, STEP)

print ('Single window of past history : {}'.format(x_train_multi[0].shape))
print ('\n Target temperature to predict : {}'.format(y_train_multi[0].shape))

BATCH_SIZE = 256
BUFFER_SIZE = 10000

train_data_multi = tf.data.Dataset.from_tensor_slices((x_train_multi, y_train_multi))
train_data_multi = train_data_multi.cache().shuffle(BUFFER_SIZE).batch(BATCH_SIZE).repeat()

val_data_multi = tf.data.Dataset.from_tensor_slices((x_val_multi, y_val_multi))
val_data_multi = val_data_multi.batch(BATCH_SIZE).repeat()

def multi_step_plot(history, true_future, prediction):
  plt.figure(figsize=(12, 6))
  num_in = create_time_steps(len(history))
  num_out = len(true_future)

  plt.plot(num_in, np.array(history[:, 1]), label='History')
  plt.plot(np.arange(num_out)/STEP, np.array(true_future), 'bo',
           label='True Future')
  if prediction.any():
    plt.plot(np.arange(num_out)/STEP, np.array(prediction), 'ro',
             label='Predicted Future')
  plt.legend(loc='upper left')
  plt.show()

for x, y in train_data_multi.take(1):
  multi_step_plot(x[0], y[0], np.array([0]))

"""The model now consists of two LSTM layers. Since 6 predictions are made, the dense layer outputs 6 predictions."""

x_train_multi.shape[-2:]

# MODEL Base
simple_model = tf.keras.models.Sequential()
simple_model.add(tf.keras.layers.LSTM(20, return_sequences=True, input_shape=x_train_multi.shape[-2:])) 
simple_model.add(tf.keras.layers.LSTM(20, return_sequences=True)) 
simple_model.add(tf.keras.layers.TimeDistributed(tf.keras.layers.Dense(96))) 
simple_model.summary() 
simple_model.compile(optimizer='adam', loss='mae')

# MODEL 1
# Convnet (for 15 min data)
multi_step_model = tf.keras.models.Sequential()
multi_step_model.add(tf.keras.layers.Conv1D(64, 5, activation='relu', input_shape=x_train_multi.shape[-2:])) 
multi_step_model.add(tf.keras.layers.MaxPooling1D(3)) 
multi_step_model.add(tf.keras.layers.Conv1D(32, 5, activation='relu')) 
multi_step_model.add(tf.keras.layers.LSTM(200, dropout=0.1, recurrent_dropout=0.5)) 
multi_step_model.add(tf.keras.layers.Dense(96)) 
multi_step_model.summary() 
multi_step_model.compile(optimizer='adam', loss='mae')

# MODEL 2
n_outputs = y_train_multi.shape[1]
# reshape output into [samples, timesteps, features]
#train_y = train_y.reshape((train_y.shape[0], train_y.shape[1], 1))
# define model
encdec = tf.keras.models.Sequential()
encdec.add(tf.keras.layers.LSTM(200, activation='relu', input_shape=x_train_multi.shape[-2:]))
encdec.add(tf.keras.layers.RepeatVector(n_outputs))
encdec.add(tf.keras.layers.LSTM(200, activation='relu', return_sequences=True))
encdec.add(tf.keras.layers.TimeDistributed(tf.keras.layers.Dense(100, activation='relu')))
encdec.add(tf.keras.layers.TimeDistributed(tf.keras.layers.Dense(1)))
encdec.summary() 
encdec.compile(loss='mse', optimizer='adam')

for x, y in val_data_multi.take(1):
  print (multi_step_model.predict(x).shape)

from keras.callbacks import ModelCheckpoint
from google.colab import drive
drive.mount('/content/drive')
filepath = "/content/drive/My Drive/{epoch:02d}-{loss:.4f}.h5"

checkpoint = ModelCheckpoint(filepath, monitor='loss',verbose=0,
                             save_best_only=True,mode='min')

callbacks_list = [checkpoint]
#model.fit(network_input, network_output, epochs=600, batch_size=64, callbacks=callbacks_list)
# weights = "16-3.1394.h5"

EVALUATION_INTERVAL = 200
EPOCHS = 10
simple_history = simple_model.fit(train_data_multi, epochs=EPOCHS,
                                          steps_per_epoch=EVALUATION_INTERVAL,
                                          validation_data=val_data_multi,
                                          validation_steps=200)

EVALUATION_INTERVAL = 200
EPOCHS = 10
multi_step_history = multi_step_model.fit(train_data_multi, epochs=EPOCHS,
                                          steps_per_epoch=EVALUATION_INTERVAL,
                                          validation_data=val_data_multi,
                                          validation_steps=200, callbacks=callbacks_list)

EVALUATION_INTERVAL = 200
EPOCHS = 10
encdec_history = encdec.fit(train_data_multi, epochs=EPOCHS,
                                          steps_per_epoch=EVALUATION_INTERVAL,
                                          validation_data=val_data_multi,
                                          validation_steps=200, callbacks=callbacks_list)

weights = "/content/drive/My Drive/03-0.5798.h5"
if(len(weights)>0): 
  multi_step_model.load_weights(weights)

def plot_train_history(history, title):
  loss = history.history['loss']
  val_loss = history.history['val_loss']

  epochs = range(len(loss))

  plt.figure()

  plt.plot(epochs, loss, 'b', label='Training loss')
  plt.plot(epochs, val_loss, 'r', label='Validation loss')
  plt.title(title)
  plt.legend()

  plt.show()

plot_train_history(multi_step_history, 'Multi-Step Training and validation loss')

plot_train_history(encdec_history, 'Encoder-Decoder Training and Test error')

predictions = np.zeros((2, 12763))
predictions[0] = dataset[TRAIN_SPLIT:, 1]

#Generate predictions from CNN-LSTM

from numpy import array
x = x_train_multi[-480]
x = array(x)
x = x.reshape((1, 480, 6))
predictions[1][0:96] = multi_step_model.predict(x)
for i in range(1, 6):
  x = x_train_multi[-480 + (i*96)] + x_val_multi[i*96]
  x = array(x)
  x = x.reshape((1, 480, 6))
  predictions[1][i*96:96 + (i*96)] = multi_step_model.predict(x)

for i in range(1, 126):
  x = x_val_multi[480 + (i*96)]
  x = array(x)
  x = x.reshape((1, 480, 6))
  predictions[1][480 + (i*96):576 + (i*96)] = multi_step_model.predict(x)

#Generate predictions from ENCODER-DECODER
from numpy import array
x = x_train_multi[-480]
x = array(x)
x = x.reshape((1, 480, 6))
y = encdec.predict(x).reshape(96)
predictions[1][0:96] = y

for i in range(1, 6):
  x = x_train_multi[-480 + (i*96)] + x_val_multi[i*96]
  x = array(x)
  x = x.reshape((1, 480, 6))
  y = encdec.predict(x).reshape(96)
  predictions[1][i*96:96 + (i*96)] = y

for i in range(1, 126):
  x = x_val_multi[480 + (i*96)]
  x = array(x)
  x = x.reshape((1, 480, 6))
  y = encdec.predict(x).reshape(96)
  predictions[1][480 + (i*96):576 + (i*96)] = y

predictions[1][6550:6560]

predictions2 = predictions.reshape((12763, 2))
df = pd.DataFrame(predictions2)
df.columns = ['Y', 'Y_hat']

df.shape

df['Y_hat'] = predictions[1]
df['Y'] = predictions[0]

df['Y_hat'][:-299]

#df = df[:-286]
df

df = df[(df != 0).all(1)]

from google.colab import files
df.to_csv('predictions_ende.csv') 
files.download('predictions_ende.csv')

for x, y in val_data_multi.take(3):
  multi_step_plot(x[0], y[0], multi_step_model.predict(x)[0])

for x, y in val_data_multi.take(30):
  multi_step_plot(x[0], y[0], encdec.predict(x)[0])