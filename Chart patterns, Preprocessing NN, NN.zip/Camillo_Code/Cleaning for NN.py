"""##Cleaning Data"""

# with technical indicators
data = pd.read_csv('https://docs.google.com/spreadsheets/d/e/2PACX-1vT_MjzkrApXlEzUxpvb0bg44QFcap9pGEKp_ay-rhWSALhMoxoXR9nMc84z6WJ7LN9IfzHVjrS9mToW/pub?gid=748044803&single=true&output=csv')

data['OPEN'] = (pd.to_numeric(data['OPEN'],downcast='float'))
data['HIGH'] = (pd.to_numeric(data['HIGH'],downcast='float'))
data['LOW'] = (pd.to_numeric(data['LOW'],downcast='float'))
data['CLOSE'] = (pd.to_numeric(data['CLOSE'],downcast='float'))
data['VOL'] = pd.to_numeric(data['VOL'],downcast='integer')
data['trend_ichimoku_a'] = pd.to_numeric(data['trend_ichimoku_a'],downcast='float')
data['trend_ichimoku_b'] = pd.to_numeric(data['trend_ichimoku_b'],downcast='float')
data['trend_macd'] = pd.to_numeric(data['trend_macd'],downcast='float')
data['volatility_bbh'] = pd.to_numeric(data['volatility_bbh'],downcast='float')
data['momentum_rsi'] = pd.to_numeric(data['volatility_bbh'],downcast='float')

data_test = pd.read_csv('https://docs.google.com/spreadsheets/d/e/2PACX-1vRpYInXcWIyH-Z8XyOWmBnCiWUYDG60AmxGlCLf-DWEqU2l_rriqv7TifV5ZOKjQ5VuJ-mzFGoe9w6c/pub?gid=1695959284&single=true&output=csv')

data_test['OPEN'] = (pd.to_numeric(data_test['OPEN'],downcast='float'))
data_test['HIGH'] = (pd.to_numeric(data_test['HIGH'],downcast='float'))
data_test['LOW'] = (pd.to_numeric(data_test['LOW'],downcast='float'))
data_test['CLOSE'] = (pd.to_numeric(data_test['CLOSE'],downcast='float'))
data_test['VOL'] = pd.to_numeric(data_test['VOL'],downcast='integer')
data_test['trend_ichimoku_a'] = pd.to_numeric(data_test['trend_ichimoku_a'],downcast='float')
data_test['trend_ichimoku_b'] = pd.to_numeric(data_test['trend_ichimoku_b'],downcast='float')
data_test['trend_macd'] = pd.to_numeric(data_test['trend_macd'],downcast='float')
data_test['volatility_bbh'] = pd.to_numeric(data_test['volatility_bbh'],downcast='float')
data_test['momentum_rsi'] = pd.to_numeric(data_test['volatility_bbh'],downcast='float')

import sklearn.preprocessing as preproc
#Min-max scaler
data['VOL'] = preproc.minmax_scale(data[['VOL']]) # between 0 - 1
data['momentum_rsi'] = preproc.minmax_scale(data[['VOL']]) # between 0 - 1

data_test['VOL'] = preproc.minmax_scale(data_test[['VOL']]) # between 0 - 1
data_test['momentum_rsi'] = preproc.minmax_scale(data_test[['VOL']]) # between 0 - 1

#data['momentum_rsi'] = preproc.minmax_scale(data[['momentum_rsi']]) # between 0 - 1
#data['trend_macd'] = preproc.minmax_scale(data[['trend_macd']]) # between 0 - 1

#data['VOL'] = preproc.StandardScaler().fit_transform(data[['VOL']])
#drop 'PER'

import seaborn as sns
corrs = data.corr()
mask = np.zeros_like(corrs)
mask[np.triu_indices_from(mask)] = True
sns.heatmap(corrs, cmap='Spectral_r', mask=mask, square=True, vmin=-.4, vmax=.4)
plt.title('Correlation matrix')

import math

# Turning the data into daily figures
dailyValues = np.zeros((1,12))
current_date = data["DATE"][0] #can be deleted?
volumeCount = data["VOL"][0]  #can be deleted?

weightedOpen = data["OPEN"][0]
weightedClose = data["CLOSE"][0]
weightedLow = data["LOW"][0]
weightedHigh = data["HIGH"][0]
dailyOpen = data["OPEN"][0]
dailyClose = 0.0
dailyLow = data["LOW"][0]
dailyHigh = data["HIGH"][0]

# volume weighted average function
def WeightedAverage(volumeCount,volume, weightedValue, value):
  weightedAverage = (volumeCount/(volumeCount+volume)) * weightedValue + (volume/(volumeCount+volume)) * value
  return weightedAverage

# for loop over all the 15 min data.
for i in range(1,121093):
  if (data['DATE'][i] == current_date): # if the 15 min interval pertains to the data that is presently under consideration.
    # add the data of the row to the current values for the current date

    tempVolume = data["VOL"][i]    
    weightedOpen = WeightedAverage(volumeCount,tempVolume,weightedOpen,data["OPEN"][i])
    weightedClose = WeightedAverage(volumeCount,tempVolume,weightedClose,data["CLOSE"][i])
    weightedLow = WeightedAverage(volumeCount,tempVolume,weightedLow,data["LOW"][i])
    weightedHigh = WeightedAverage(volumeCount,tempVolume,weightedHigh,data["HIGH"][i])
    weightedMACD = WeightedAverage(volumeCount,tempVolume,weightedHigh,data["trend_macd"][i])
    weightedMOM = WeightedAverage(volumeCount,tempVolume,weightedHigh,data["momentum_rsi"][i])

    # Check whether daily high / low value was achieved in this 15 min period 
    if(data['LOW'][i] < dailyLow):
      dailyLow = data['LOW'][i]
    if(data['HIGH'][i] > dailyHigh):
      dailyHigh = data['HIGH'][i]

    # update the volume last for computation reasons  
    volumeCount += data['VOL'][i]

  else: # if a new day has begun.
    # 1. finalize the computation of daily averages by adding the computed values to the array
    dailyClose = data["CLOSE"][i-1] # fix the final closing value of the day

    current = np.array([current_date,volumeCount,weightedOpen,weightedClose, weightedLow, weightedHigh, dailyOpen,dailyClose, dailyLow, dailyHigh, weightedMACD, weightedMOM], ndmin=2)
    dailyValues = np.append(dailyValues, current,axis = 0)

    # 2. initialize a new day by setting current_date to the new date that is started
    current_date = data["DATE"][i]
    
    weightedOpen = data["OPEN"][i]
    weightedClose = data["CLOSE"][i]
    weightedLow = data["LOW"][i]
    weightedHigh = data["HIGH"][i]
    dailyOpen = data["OPEN"][i]
    dailyClose = 0.0
    dailyLow = data["LOW"][i]
    dailyHigh = data["HIGH"][i]
    weightedMACD = data["trend_macd"][i]
    weightedMOM = data["momentum_rsi"][i]

    volumeCount = data['VOL'][i]

daily_Dataframe = pd.DataFrame(dailyValues, columns=['Date', 'Vol','weightedOpen','weightedClose', 'weightedLow', 'weightedHigh', 'dailyOpen','dailyClose', 'dailyLow', 'dailyHigh', 'weightedMACD', 'weightedMOM'])
daily_Dataframe.drop(daily_Dataframe.index[0])

#Fix date issues for daily_Dataframe

for i in range(1, 1717): #disregarding first row
    date1 = str(daily_Dataframe['Date'][i])
    y = date1[0:4]
    m = date1[4:6]
    d = date1[6:8]
    daily_Dataframe['Date'][i] = d + m + y
    daily_Dataframe['Date'][i] =  pd.to_datetime(daily_Dataframe['Date'][i], format='%d%m%Y') #how to get rid of time?

# Delete first and last entry
daily_Dataframe = daily_Dataframe[:-3]
daily_Dataframe = daily_Dataframe[1:]

#Fix date for data
forex = data.copy()

for i in range(0, 121090):
    date1 = str(forex['DATE'][i])
    y = date1[0:4]
    m = date1[4:6]
    d = date1[6:8]
    date2 = int(forex['TIME'][i])
    date2 = str(date2)
    if (len(date2) == 6):
      h = date2[0:2]
      mi = date2[2:4]
      forex['DATE'][i] = d + m + y + ' ' + h + mi
      forex['DATE'][i] = pd.to_datetime(forex['DATE'][i], format='%d%m%Y %H%M')
    elif (len(date2) == 5):
      h = '0' + date2[0:1] 
      mi = date2[1:3]
      forex['DATE'][i] = d + m + y + ' ' + h + mi
      forex['DATE'][i] = pd.to_datetime(forex['DATE'][i], format='%d%m%Y %H%M')
    elif (len(date2) == 4):
      mi = date2[0:2]
      forex['DATE'][i] = d + m + y + ' ' + mi
      forex['DATE'][i] = pd.to_datetime(forex['DATE'][i], format='%d%m%Y %M')
    elif (len(date2) == 1):
      mi = date2[0:1]
      forex['DATE'][i] = d + m + y + ' ' + mi
      forex['DATE'][i] = pd.to_datetime(forex['DATE'][i], format='%d%m%Y %M')


# Delete first and last entry
#forex = forex[:-1]
forex

forex = forex[:-3]
forex = forex.drop(columns=['TIME', 'PER', 'Unnamed: 0',	'TICKER'])
forex

#fix time for test_data
forex_test = data_test.copy()
for i in range(0, 6523):
    date1 = str(forex_test['DATE'][i])
    y = date1[0:4]
    m = date1[4:6]
    d = date1[6:8]
    date2 = int(forex_test['TIME'][i])
    date2 = str(date2)
    if (len(date2) == 6):
      h = date2[0:2]
      mi = date2[2:4]
      forex_test['DATE'][i] = d + m + y + ' ' + h + mi
      forex_test['DATE'][i] = pd.to_datetime(forex_test['DATE'][i], format='%d%m%Y %H%M')
    elif (len(date2) == 5):
      h = '0' + date2[0:1] 
      mi = date2[1:3]
      forex_test['DATE'][i] = d + m + y + ' ' + h + mi
      forex_test['DATE'][i] = pd.to_datetime(forex_test['DATE'][i], format='%d%m%Y %H%M')
    elif (len(date2) == 4):
      mi = date2[0:2]
      forex_test['DATE'][i] = d + m + y + ' ' + mi
      forex_test['DATE'][i] = pd.to_datetime(forex_test['DATE'][i], format='%d%m%Y %M')
    elif (len(date2) == 1):
      mi = date2[0:1]
      forex_test['DATE'][i] = d + m + y + ' ' + mi
      forex_test['DATE'][i] = pd.to_datetime(forex_test['DATE'][i], format='%d%m%Y %M')

from google.colab import files
forex.to_csv('forex.csv') 
files.download('forex.csv')

from google.colab import files
forex_test.to_csv('forex_test.csv') 
files.download('forex_test.csv')